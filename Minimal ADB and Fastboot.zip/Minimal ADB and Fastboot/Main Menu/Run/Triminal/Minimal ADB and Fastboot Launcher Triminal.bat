echo off
cls
echo =======================
echo USING ADMINISTRATOR CMD
echo =======================
echo 1. YES
echo 2. NO
set /p adminis=YES/NO:

if %adminis%==1 goto admin
if %adminis%==2 goto con

:admin
net session >nul 2>&1 || (powershell -Command "Start-Process '%~f0' -Verb RunAs" & exit)
cls
goto con


:con
set /p path=TYPE PATH FOLDER ADB:
cd %path%
:mainmenu
cls
echo =============
echo USING VERSION
echo =============
echo 1. Oficial
echo 2. UNOficial
set /p main=Select:

if %main%==1 goto of
if %main%==2 goto un

:of
cd "Oficial ADB & Fastboot"
cls
cmd /k echo ADB CONSOL CMD TYPE "EXIT" To EXIT

:exitof
cd %path%
cls
goto mainmenu

:un
cd "UNOficial ADB & Fastboot"
cls
cmd /k echo ADB CONSOL CMD TYPE "EXIT" To EXIT

:exitun
cd %path%
cls
goto mainmenu