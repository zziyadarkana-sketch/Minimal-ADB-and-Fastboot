cd ..
set mypath=%cd%
cls
echo off
cls
echo =====================
echo YOUR PATH
echo =====================
echo PATH:%cd%
Pause